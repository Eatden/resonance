package com.keiro.musicplayer.data

import android.net.Uri

/**
 * A single track pulled from MediaStore.
 * [format] is derived from the file extension so the UI can badge
 * lossless files (FLAC / WAV / ALAC) distinctly from lossy ones.
 */
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val contentUri: Uri,
    val albumArtUri: Uri?,
    val filePath: String,
    val format: AudioFormat
) {
    val isLossless: Boolean get() = format == AudioFormat.FLAC || format == AudioFormat.WAV || format == AudioFormat.ALAC
}

enum class AudioFormat(val extension: String, val label: String) {
    FLAC("flac", "FLAC"),
    WAV("wav", "WAV"),
    ALAC("m4a", "ALAC"),
    MP3("mp3", "MP3"),
    AAC("aac", "AAC"),
    OGG("ogg", "OGG"),
    OTHER("", "Audio");

    companion object {
        fun fromPath(path: String): AudioFormat {
            val ext = path.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "flac" -> FLAC
                "wav" -> WAV
                "m4a" -> ALAC // heuristic; true ALAC vs AAC both use .m4a
                "mp3" -> MP3
                "aac" -> AAC
                "ogg", "opus" -> OGG
                else -> OTHER
            }
        }
    }
}
